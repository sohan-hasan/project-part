// import { CustomBlock } from "ngx-blockly";

// declare var Blockly: any;

// export class CustomCommentBlock extends CustomBlock{
    
//     // constructor() {
//     //     super('comment_tag', null, null);
//     //     this.class = CustomCommentBlock;
//     // }
//     // defineBlock() {
//     //     this.block
//     //     .appendDummyInput()
//     //     .appendField('//')
//     //     .appendField(new Blockly.FieldTextInput('comment'),'comment_text');

//     //     this.block.setPreviousStatement(true, null);
//     //     this.block.setNextStatement(true, null);
//     //     this.block.setColour(75);
//     // }

//     // public toJavaScriptCode(block: any): string | any[]{
//     //     const text_comment_text = block.getFieldValue('comment_text');
//     //     const code = '//' + text_comment_text + '\n';
//     //     return code;
//     // }
// }