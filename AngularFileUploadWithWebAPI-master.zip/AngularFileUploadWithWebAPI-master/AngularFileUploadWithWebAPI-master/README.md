# Angular Fileupload With Asp.Net Web API C#
Steps to run
# 1. Clone the Repository
# 2. Create the DB using the script file
# 3. Modify the connectionstring in Web API project
# 4. Restore node modules for Angular APP
# 5. Restore the nuget packages for Web API
# 6. Run the Web API project
# 7. Run the Angular App
