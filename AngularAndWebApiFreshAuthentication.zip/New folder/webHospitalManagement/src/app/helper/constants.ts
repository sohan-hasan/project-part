export class Constants{
    public static readonly USER_KEY:string="userInfo";
    public static readonly API_KEY:string="https://localhost:44307/"
}
  