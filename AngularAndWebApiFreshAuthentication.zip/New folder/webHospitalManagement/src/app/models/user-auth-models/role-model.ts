export class RoleModel {
    public id?: string ;
    public name?: string ;
  }
  